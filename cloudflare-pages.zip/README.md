# Despliegue en Cloudflare Pages

Este paquete contiene todos los archivos listos para subir a tu proyecto de Cloudflare Pages sin pasos de compilación.

## Archivos incluidos:
- **index.html**: Código completo, autocontenido, responsivo y optimizado con Hero 3D, carrusel y mock de tienda.
- **logo-hogar-novedades.jpg**: El logo oficial extraído del repositorio de GitHub (hogar-novedades-assets).
- **_headers**: Configuración de caché y seguridad recomendada por Cloudflare.
- **_routes.json**: Enrutamiento estático para Cloudflare Pages.

## Cómo desplegar en Cloudflare Pages:

### Opción 1: Subida Directa (Drag and Drop)
1. Entra a tu panel de **Cloudflare Dashboard** -> **Workers & Pages**.
2. Haz clic en **Create application** -> **Pages** -> **Upload assets**.
3. Ponle un nombre a tu proyecto (ej: `hogar-novedades` o `vision-vertex`).
4. Arrastra la carpeta `cloudflare-dist` o sube el archivo `cloudflare-pages.zip`.
5. Haz clic en **Deploy site**. ¡Listo! Tu web estará en vivo en segundos.

### Opción 2: Conectar con GitHub
1. Sube estos archivos a tu repositorio de GitHub.
2. En Cloudflare Pages, selecciona **Connect to Git**.
3. En Build Settings selecciona:
   - Framework preset: **None** (HTML estático)
   - Build output directory: `/` o `cloudflare-dist`
4. Haz clic en **Save and Deploy**.
